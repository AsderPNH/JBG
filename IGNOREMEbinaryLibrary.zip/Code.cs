﻿using System;

namespace ConsoleApp1
{
    class Program
    {
        static void Main(string[] args)
        {
            /*---------------------------------
            | Programm: Mathequiz
            | Autor: Paul "AsderPNH" Hoffmann
            | Version: 1.0
            ---------------------------------*/

            // Programmfenster einen Namen geben
            Console.Title = "Mathequiz";

            // Unendliche Programmwiederholung
            while (true)
            {
                // Trennlinie (70 Striche) + Überschrift (siehe Unterprogramm)
                Intro(70, true);

                // Eingabe
                Console.Write("\nGeben Sie jetzt bitte die Anzahl an gewünschten Runden ein.\nZum schließen der App, geben Sie bitte einfach \"close\" ein: ");
                string input = Console.ReadLine();
                int rounds = 0;

                // Schleife für ungültigen Input
                bool rightInput = false;
                while (rightInput == false)
                {
                    // Versucht Eingabe-String in eine Zahl umzuwandeln
                    try
                    {
                        rounds = Convert.ToInt32(input);
                        rightInput = true; // Schleifenausweg steht dem potenziellen Error-Befehl | Wird also nur aktiviert, wenn dieser nicht Auftritt -> Eingabe richtig ist
                    }
                    catch (FormatException) // Falls bei der Umwandlung ein Fehler auftritt
                    {
                        if (input == "close") // Falls der Eingabe-String das -zum Schließen des Programms- angeforderte "close" beinhaltet
                        {
                            Environment.Exit(0); // Schließt Programm
                        }
                        else
                        {
                            Console.Clear(); // Löscht den Text des Konsolenfelds
                            Intro(70, true);
                            Console.WriteLine("\nUngültige Eingabe, versuchen sie es bitte erneut"); // Errormeldung für den User und daraufhin erneuter Schleifendurchlauf
                            Console.ReadKey();
                            Console.Clear();
                        }
                    }
                }
                Console.Clear();

                // Speichern der Startzeit
                DateTime startTime1 = DateTime.Now;

                // Variablendeklaration für die spätere Prozentrechnung und Tabellenausgabe
                int correctSolutions = 0, wrongSolutions = 0;
                string table = "";

                // Quizrunden
                for (int i = 0; i < rounds; i++)
                {
                    // randomZahlen generieren
                    Random randomNum = new Random(); // randomNum als Randomzahl deklarieren
                    int choice = randomNum.Next(0, 3); // choice kann 0-2 sein
                    int number1 = randomNum.Next(1, 501); // Zahl 1 kann 1-500 sein
                    int number2 = randomNum.Next(2, 11); // Zahl 2 kann 2-10 sein
                    int number3 = randomNum.Next(2, 11); // Zahl 3 kann ebenfalls 2-10 sein

                    // intere Berechnung der Lösung und Ausgabe der Rechenaufgaben
                    int solution = 0;

                    // Schleife für ungültigen Input
                    rightInput = false;
                    int inputSolution = 0;
                    while (rightInput == false)
                    {
                        Intro(70, true);
                        if (choice < 2) // 2/3 Chance, dass es eine Additionsrechnung ist
                        {
                            Console.Write($"\nGeben Sie die Lösung der folgenden Rechnung ein:\n{number1} + {number2} * {number3}: ");
                            solution = number1 + number2 * number3;
                        }
                        else // 1/3 Chance, dass es eine Subtraktionsrechnung ist
                        {
                            Console.Write($"\nGeben Sie die Lösung der folgenden Rechnung ein:\n{number1} - {number2} * {number3}: ");
                            solution = number1 - number2 * number3;
                        }

                        // Überprüfung der Eingabe
                        input = Console.ReadLine();
                        try
                        {
                            inputSolution = Convert.ToInt32(input);
                            rightInput = true;
                        }
                        catch (FormatException)
                        {
                            Console.Clear();
                            Intro(70, true);
                            Console.WriteLine("\nUngültige Eingabe. Bitte versuchen Sie es erneut.");
                            Console.ReadKey();
                            Console.Clear();
                        }
                    }

                    // Abgleichen der Eingabe mit der Lösung und erweitern der Output-Tabelle
                    if (inputSolution == solution)
                    {
                        correctSolutions++; // Erhöhung der correctSolutions-Variable bei richtiger Antwort
                        table += $"{inputSolution}\tCorrect\n";
                    }
                    else
                    {
                        wrongSolutions++; // Sonst Erhöhung der wrongSolutions-Variable
                        table += $"{inputSolution}\t{solution}\n";
                    }
                    Console.Clear();
                }

                // Speichern der Startzeit
                DateTime endTime1 = DateTime.Now;

                // Finale Ausgabe
                Intro(70, true);
                Console.Write($"\nEingabe\tLoesung\n\n{table}"); // Tabellenausgabe
                Intro(70, false);
                Console.WriteLine($"\nDu hast {correctSolutions * 100 / (correctSolutions + wrongSolutions)}% der Aufgaben richtig."); // Prozentrechnung
                Console.ReadKey();
                Console.Clear();
            }

            // Unterprogramm für Trennstriche und Überschrift
            static void Intro(int Count, bool Name)
            {
                if (Name == true)
                {
                    Console.WriteLine("Mathequiz");
                }
                for (int i = 0; i < Count; i++)
                {
                    Console.Write('-');
                }
            }
            Console.WriteLine("Hit Enter to quit");
            Console.ReadLine();
        }
    }
}
